# Template directory
This directory is used to store templates.
